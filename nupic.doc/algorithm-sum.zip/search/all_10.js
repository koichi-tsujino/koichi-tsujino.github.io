var searchData=
[
  ['update',['update',['../classnupic_1_1algorithms_1_1spatial__pooler_1_1__SparseMatrixCorticalColumnAdapter.html#a5732f740169f380fc52ec7e61f34ebe0',1,'nupic::algorithms::spatial_pooler::_SparseMatrixCorticalColumnAdapter']]],
  ['updatesynapsepermanence',['updateSynapsePermanence',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#ad185b561dccb4da549c27768290c5651',1,'nupic::algorithms::connections::Connections']]],
  ['updatesynapses',['updateSynapses',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#ae069f4b98aef21ca8569f5e0b079cff7',1,'nupic::algorithms::backtracking_tm::Segment']]]
];

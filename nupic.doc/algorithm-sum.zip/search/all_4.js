var searchData=
[
  ['dataforsegment',['dataForSegment',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a96b21d2b0a550ba5b0284acb7c49e7c2',1,'nupic::algorithms::connections::Connections']]],
  ['dataforsynapse',['dataForSynapse',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a023158178457a974dbbbcf43a6f670c3',1,'nupic::algorithms::connections::Connections']]],
  ['debugprint',['debugPrint',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#a34ab41284bf657365fbd35156cd874f1',1,'nupic::algorithms::backtracking_tm::Segment']]],
  ['destroysegment',['destroySegment',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#af0002952ee37663a3f9b834b9db4883c',1,'nupic::algorithms::connections::Connections']]],
  ['destroysynapse',['destroySynapse',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a769aadc057a9e9463f3151f15591b091',1,'nupic::algorithms::connections::Connections']]],
  ['doiteration',['doIteration',['../classnupic_1_1algorithms_1_1knn__classifier_1_1KNNClassifier.html#abc03d759531ae49ee162f8a8887e7b92',1,'nupic::algorithms::knn_classifier::KNNClassifier']]],
  ['dopooling',['doPooling',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#a6ca9b0a386c97fa1872640abe17a4e10',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]],
  ['dutycycle',['dutyCycle',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#ab357dd42935afdb2c0d691252f6b5d62',1,'nupic::algorithms::backtracking_tm::Segment']]],
  ['dutycyclealphas',['dutyCycleAlphas',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#a4324bd2fe91782a01d6a2a4291e8c56c',1,'nupic::algorithms::backtracking_tm::Segment']]],
  ['dutycycletiers',['dutyCycleTiers',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#acd20a3dc2b08a320f9d22ba5bcaa4f25',1,'nupic::algorithms::backtracking_tm::Segment']]],
  ['dynamicgroupingfunction',['DynamicGroupingFunction',['../classnupic_1_1algorithms_1_1utils_1_1DynamicGroupingFunction.html',1,'nupic::algorithms::utils']]],
  ['dynamicimport',['DynamicImport',['../classnupic_1_1algorithms_1_1utils_1_1DynamicImport.html',1,'nupic::algorithms::utils']]]
];

var searchData=
[
  ['finishlearning',['finishLearning',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#a295beb277c2c0e51863ad078709fef9b',1,'nupic.algorithms.backtracking_tm.BacktrackingTM.finishLearning()'],['../classnupic_1_1algorithms_1_1backtracking__tm__cpp_1_1BacktrackingTMCPP.html#abb812261d3d03fad630f7828c98f2584',1,'nupic.algorithms.backtracking_tm_cpp.BacktrackingTMCPP.finishLearning()'],['../classnupic_1_1algorithms_1_1knn__classifier_1_1KNNClassifier.html#aaab255f20c9590619aca4c67d03b1f8e',1,'nupic.algorithms.knn_classifier.KNNClassifier.finishLearning()']]],
  ['freensynapses',['freeNSynapses',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#a1d14ff0ea4e17b59b5aff39de46ee2a9',1,'nupic::algorithms::backtracking_tm::Segment']]]
];

var searchData=
[
  ['numberofcells',['numberOfCells',['../classnupic_1_1algorithms_1_1temporal__memory_1_1TemporalMemory.html#ae4be62b469e83f9d26393d0460d69bb9',1,'nupic::algorithms::temporal_memory::TemporalMemory']]],
  ['numberofcolumns',['numberOfColumns',['../classnupic_1_1algorithms_1_1temporal__memory_1_1TemporalMemory.html#a2a133fa133555942e756024b34c2459e',1,'nupic::algorithms::temporal_memory::TemporalMemory']]],
  ['numsegments',['numSegments',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a8139635c61dabdc4f3da57a8d22e0958',1,'nupic::algorithms::connections::Connections']]],
  ['numsynapses',['numSynapses',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a63d9531c068407b5705b1737fd47e9a1',1,'nupic::algorithms::connections::Connections']]]
];

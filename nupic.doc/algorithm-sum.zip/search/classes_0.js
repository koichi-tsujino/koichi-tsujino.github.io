var searchData=
[
  ['_5fsegmentupdate',['_SegmentUpdate',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM_1_1__SegmentUpdate.html',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]],
  ['_5fsparsematrixcorticalcolumnadapter',['_SparseMatrixCorticalColumnAdapter',['../classnupic_1_1algorithms_1_1spatial__pooler_1_1__SparseMatrixCorticalColumnAdapter.html',1,'nupic::algorithms::spatial_pooler']]]
];

var searchData=
[
  ['celldata',['CellData',['../classnupic_1_1algorithms_1_1connections_1_1CellData.html',1,'nupic::algorithms::connections']]],
  ['connections',['Connections',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html',1,'nupic::algorithms::connections']]],
  ['corticalcolumns',['CorticalColumns',['../classnupic_1_1algorithms_1_1spatial__pooler_1_1CorticalColumns.html',1,'nupic::algorithms::spatial_pooler']]]
];

var searchData=
[
  ['invalidspparamvalueerror',['InvalidSPParamValueError',['../classnupic_1_1algorithms_1_1spatial__pooler_1_1InvalidSPParamValueError.html',1,'nupic::algorithms::spatial_pooler']]]
];

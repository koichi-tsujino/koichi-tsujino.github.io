var searchData=
[
  ['knnclassifier',['KNNClassifier',['../classnupic_1_1algorithms_1_1knn__classifier_1_1KNNClassifier.html',1,'nupic::algorithms::knn_classifier']]]
];

var searchData=
[
  ['monitoredtemporalmemory',['MonitoredTemporalMemory',['../classnupic_1_1algorithms_1_1backtracking__tm__shim_1_1MonitoredTemporalMemory.html',1,'nupic::algorithms::backtracking_tm_shim']]],
  ['monitoredtmshim',['MonitoredTMShim',['../classnupic_1_1algorithms_1_1backtracking__tm__shim_1_1MonitoredTMShim.html',1,'nupic::algorithms::backtracking_tm_shim']]]
];

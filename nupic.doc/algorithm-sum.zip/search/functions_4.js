var searchData=
[
  ['dataforsegment',['dataForSegment',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a96b21d2b0a550ba5b0284acb7c49e7c2',1,'nupic::algorithms::connections::Connections']]],
  ['dataforsynapse',['dataForSynapse',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a023158178457a974dbbbcf43a6f670c3',1,'nupic::algorithms::connections::Connections']]],
  ['debugprint',['debugPrint',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#a34ab41284bf657365fbd35156cd874f1',1,'nupic::algorithms::backtracking_tm::Segment']]],
  ['destroysegment',['destroySegment',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#af0002952ee37663a3f9b834b9db4883c',1,'nupic::algorithms::connections::Connections']]],
  ['destroysynapse',['destroySynapse',['../classnupic_1_1algorithms_1_1connections_1_1Connections.html#a769aadc057a9e9463f3151f15591b091',1,'nupic::algorithms::connections::Connections']]],
  ['doiteration',['doIteration',['../classnupic_1_1algorithms_1_1knn__classifier_1_1KNNClassifier.html#abc03d759531ae49ee162f8a8887e7b92',1,'nupic::algorithms::knn_classifier::KNNClassifier']]],
  ['dutycycle',['dutyCycle',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#ab357dd42935afdb2c0d691252f6b5d62',1,'nupic::algorithms::backtracking_tm::Segment']]]
];

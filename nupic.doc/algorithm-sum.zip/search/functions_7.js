var searchData=
[
  ['infer',['infer',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#a817289e33d1d28515cd502f109bdd232',1,'nupic.algorithms.backtracking_tm.BacktrackingTM.infer()'],['../classnupic_1_1algorithms_1_1knn__classifier_1_1KNNClassifier.html#a90bfb66151547cad4325ea7b8e66c97e',1,'nupic.algorithms.knn_classifier.KNNClassifier.infer()'],['../classnupic_1_1algorithms_1_1sdr__classifier_1_1SDRClassifier.html#a433d6b96e419248e92768109e8c2a0d4',1,'nupic.algorithms.sdr_classifier.SDRClassifier.infer()']]],
  ['infersinglestep',['inferSingleStep',['../classnupic_1_1algorithms_1_1sdr__classifier_1_1SDRClassifier.html#a79b18ad694ebdd75176afaf5b6b8ef7d',1,'nupic::algorithms::sdr_classifier::SDRClassifier']]]
];

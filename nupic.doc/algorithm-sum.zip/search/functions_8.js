var searchData=
[
  ['learn',['learn',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#a4b04004bafa578622a59094d10253981',1,'nupic.algorithms.backtracking_tm.BacktrackingTM.learn()'],['../classnupic_1_1algorithms_1_1knn__classifier_1_1KNNClassifier.html#a15282d807ba6c5787870da3c6b19e163',1,'nupic.algorithms.knn_classifier.KNNClassifier.learn()']]],
  ['loadfromfile',['loadFromFile',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#ac30da2e6e76b40ef24d0ea8894cbe188',1,'nupic.algorithms.backtracking_tm.BacktrackingTM.loadFromFile()'],['../classnupic_1_1algorithms_1_1backtracking__tm__cpp_1_1BacktrackingTMCPP.html#a50ce4933562a2f65318ad67d7add319e',1,'nupic.algorithms.backtracking_tm_cpp.BacktrackingTMCPP.loadFromFile()']]]
];

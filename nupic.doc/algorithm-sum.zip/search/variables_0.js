var searchData=
[
  ['avginputdensity',['avgInputDensity',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#ab701fed60e345d6ff286b28b6f74f1e3',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]],
  ['avglearnedseqlength',['avgLearnedSeqLength',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#af3ec374667293c1c45bfe850a9873bad',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]]
];

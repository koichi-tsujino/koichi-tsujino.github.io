var searchData=
[
  ['burnin',['burnIn',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#ad2f9894950a42aa331a62087809c8098',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]]
];

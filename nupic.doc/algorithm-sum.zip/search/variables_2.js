var searchData=
[
  ['cells',['cells',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#a0707cd8ace832ba6bd3620cf3037b9c2',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]],
  ['collectsequencestats',['collectSequenceStats',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#aaad0cff4c1ad7960d4c2fee0da4b0127',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]],
  ['collectstats',['collectStats',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#aeee7d48a0855b5c6ba73a52fbb440685',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]]
];

var searchData=
[
  ['dopooling',['doPooling',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#a6ca9b0a386c97fa1872640abe17a4e10',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]],
  ['dutycyclealphas',['dutyCycleAlphas',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#a4324bd2fe91782a01d6a2a4291e8c56c',1,'nupic::algorithms::backtracking_tm::Segment']]],
  ['dutycycletiers',['dutyCycleTiers',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1Segment.html#acd20a3dc2b08a320f9d22ba5bcaa4f25',1,'nupic::algorithms::backtracking_tm::Segment']]]
];

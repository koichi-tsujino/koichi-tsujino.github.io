var searchData=
[
  ['pamcounter',['pamCounter',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#aa153eb345ec06f4fa26a3689a95fc256',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]]
];

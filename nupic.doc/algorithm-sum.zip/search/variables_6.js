var searchData=
[
  ['resetcalled',['resetCalled',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#a9e55e738bc9d7a2038ccf0ec7c03887a',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]]
];

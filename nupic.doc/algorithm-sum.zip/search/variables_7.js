var searchData=
[
  ['segid',['segID',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#aeef343ff8059ea3b01d3cefaff678723',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]],
  ['segmentupdates',['segmentUpdates',['../classnupic_1_1algorithms_1_1backtracking__tm_1_1BacktrackingTM.html#af85b0fd41418d05034f572956468148a',1,'nupic::algorithms::backtracking_tm::BacktrackingTM']]]
];
